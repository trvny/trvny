# karpathy-skills (merged)

One `karpathy-guidelines` skill, deduplicated from 5 forks:

- chius-me/andrej-karpathy-skills-opencode (opencode tool-call phrasing)
- twj515895394/andrej-karpathy-skills-12 (12-rule extension: model-use scope, token budgets, conflict handling, checkpointing, fail-loud)
- hsliuustc0106/hsliuustc0106-skills (agentic-coding-guidelines variant: repo-aware work, never-revert rule)
- datajuny/andrej-karpathy-skills (Korean-output conventions, plan+checklist+notes, semantic commits)
- doggy8088/andrej-karpathy-skills (base 4 rules)

All 4 English variants of the core skill were near-identical on rules 1–4; everything unique from each was folded into `skills/karpathy-guidelines/SKILL.md` as 14 numbered rules + a conditional non-English-output appendix. Nothing dropped, nothing duplicated.

**Not merged:** hsliuustc0106's project-specific skills (`afd-plugin-guidelines`, `vllm-guidelines`, `vllm-omni-*`, `tech-blog-post`, `build-slides-interactively`) and twj's standalone Chinese translation — these aren't karpathy-guidelines content, just other things that happened to live in that fork. Say the word if you want those pulled in too.

License: MIT (per all source repos).
