# LLM-SKILL

Runnable Implementation: https://github.com/hanyuancheung/llm-skill

> This is a first-person record of how I took Karpathy's [LLM-Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) intuition and turned it, step by step, into the `llm-skill` project. I'll walk through: where I started, why I chose this particular layering, what each layer solves.

---

## 1. Starting point: what I actually took away from LLM-Wiki

Karpathy's LLM-Wiki throws out one core intuition:

> **Humans don't get smarter by memorizing "every conversation" — they distill conversations into entries, and next time a similar problem shows up, they look up the entry first.**

Translated into the LLM-Agent context, three signals jumped out at me:

1. **Context is not free.** Every chunk you stuff into a prompt burns tokens and burns attention. You should only pack in "the small slice this task actually needs".
2. **Experience needs a middle layer.** Raw conversations are, well, raw; model weights are frozen. What's missing in between is **an incrementally editable, structured experience layer** — i.e. the Wiki.
3. **The Wiki isn't a static doc; it's a living organism.** Somebody writes it (distilling), somebody reads it (executing), somebody curates it (routing and health). These three roles **must** be separated.

So I gave myself a design brief:

> Build a **minimal, runnable, self-evolving Skill system** that lets an Agent, on every task: **read as little as possible → do the right thing → sink whatever it newly learned back into the Wiki**.

---

## 2. My three-layer mental model: Raw / Wiki / Schema

Before writing any code I forced the whole system into three layers, and laid down a rule: **each layer only ever talks about one thing**. This is the deepest invariant of the project.

| Layer | What it is | Who writes it | Who reads it |
|---|---|---|---|
| **Raw layer** | Chat, tool output, errors, pitfalls as they happen | User + Agent, ephemeral | Only `distill` consumes it |
| **Wiki layer** | `skills/<name>/SKILL.md` | **Only `distill`** can write | `execute` lazy-loads on demand |
| **Schema layer** | `AGENT.md` (routing + contract) | **Only `guide`** can write | `execute` must read at the start of every task |

**The decision that matters most here**: I cleanly separated "domain knowledge" from "routing rules". **Not a single line of domain knowledge is allowed inside `AGENT.md`.** It answers only one question: "in what situation do I use which skill, and how do they cooperate?" Only then does the Schema stay stable, short, and trustworthy.

This model lands directly in the repo layout:

```
llm-skill/
├── AGENT.md            ← Schema (single source of truth)
├── skills/
│   ├── execute/        ← meta-skill: run tasks
│   ├── distill/        ← meta-skill: write the Wiki
│   ├── guide/          ← meta-skill: maintain the Schema
│   └── _template/      ← scaffold for domain skills
└── scripts/validate.py ← contract guard
```

---

## 3. The closed loop: Execute → Distill → Guide

With only layering, the system is static. I wanted **evolution**, so I wrapped the three layers in a loop:

```
          ┌────────────────────────────────────────────────┐
          ▼                                                │
[Execute] ──traces──► [Distill] ──skill CRUD──► [Guide]
  run tasks           refine into skills        maintain routing
  reads Schema                                  writes Schema
     ▲                                                │
     │                                                │
     └──── next task routed by the new rules ◄────────┘
```

I gave the three meta-skills **mutually exclusive write rights** — this is the single decision that keeps the whole thing from rotting:

| Meta-skill | Reads | Writes | Absolutely must not |
|---|---|---|---|
| `execute` | `AGENT.md` + up to 3 `SKILL.md` files | **Nothing** (read-only on skills) | Batch-read `skills/`; edit any skill |
| `distill` | Raw traces + existing skills | Only `skills/<name>/SKILL.md` | Touch `AGENT.md` |
| `guide` | Every skill's front-matter | Only the routing table + changelog in `AGENT.md` | Stuff domain knowledge into `AGENT.md` |

**Why make writes exclusive?**
Because an Agent that mutates its own rules while executing is a debugging nightmare. Once writes are exclusive, every behavioral change can be traced to "which meta-skill touched which file in which turn".

---

## 4. Why a skill must be "contract + body"

This is the **SKILL contract** I locked down as early as v0.1.0 (see `AGENT.md` §3):

- **front-matter (the contract)**: `name / version / status / triggers / dependencies / owner / updated` — all seven required, no exceptions.
- **body (six fixed sections)**: What / When (at least 2 positive + 2 negative examples) / How (numbered SOP) / Examples / Pitfalls / Changelog.

Two things I particularly care about:

1. **Two vital signs: `version` + `status`**
   - `version` lets me do semantic upgrades (patch / added SOP step / contract change).
   - `status` powers the **lifecycle state machine**: `experimental → active → deprecated → removed`. A skill's whole life is trackable, from birth to retirement.

2. **Every `Pitfall` must come from a real trace**
   This is a hard rule I enforce on myself: pitfalls that grow out of raw usage are the valuable ones; fabricated pitfalls are pollution. The `distill` SOP explicitly uses "can every Pitfall be stated as *if A then B*?" as a quality gate.

3. **Hard cap on lazy loading: at most 3 `SKILL.md` per task**
   This maps directly to the opening "context is not free". Step 1 of the `execute` SOP reads: "**Read only §2 of `AGENT.md`; do NOT `ls skills/` or batch-read.**"

---

## 5. How I hardened it across three iterations

This didn't land in one shot. I filled the holes version by version — this section maps directly onto the repo's `CHANGELOG.md`.

### v0.1.0 — stand up the skeleton

I only shipped the minimal loop:
- `AGENT.md`: routing table + SKILL contract + lifecycle state machine + anti-patterns.
- Three meta-skill directories: `execute / distill / guide`.
- The `_template` scaffold.

**What this version solves**: the idea runs end-to-end — the Agent reads the Schema, lazy-loads skills, and reminds itself to distill after finishing.

**What this version lacks**:
- English only; not friendly to non-English users.
- No entrypoint adapters for different Agent runtimes (Codex / Claude Code / HERMES).
- No mechanical guard whatsoever — the whole contract relied on "trust the Agent to obey".

### v0.2.0 — make it genuinely installable and verifiable

I added four things:

1. **Bilingual mirrors**: every skill ships both `SKILL.md` (English, default) and `SKILL_zh.md` (Chinese mirror). The front-matter fields `name/version/status` **must match**; the body may be translated.
2. **Thin entrypoint shells for multiple runtimes**: `AGENTS.md` (Codex), `CLAUDE.md` (Claude Code), `HERMES.md` (HERMES) — all **purely shells** that defer to `AGENT.md`. Same Schema, any runtime.
3. **`install.sh`**: one-shot layout check + validator invocation.
4. **`scripts/validate.py`**: verifies three things — front-matter shape, directory name equals `name`, and bi-directional consistency between `AGENT.md` §2 and the real `skills/` tree.

**The breakthrough of this version**: upgrade from "trust the Agent to behave" to "a mechanical guard that can reject bad commits".

### v0.3.0 — the Hook protocol: mechanize "is there anything I still need to do before I finish?"

This is the iteration I'm proudest of.

**The problem**:
After `execute` finishes a task, it should evaluate "did this run produce anything worth distilling?" But "should" is not enough — Agents will cut corners, skip evaluations, and rationalize away with "nothing worth distilling this time".

**My solution**: introduce the **Hook protocol** (`AGENT.md` §10) — three lifecycle anchor points:

| Phase | When it fires | Typical purpose |
|---|---|---|
| `pre` | After routing, before running `How` | Guard conditions; `skip` / `warn` / `proceed` |
| `post` | Before `execute` declares "done" | Distill judgement, validators, side-effect checks |
| `on_error` | On any raise or user abort | Cleanup, rollback, log extraction |

**I whitelisted the set of actions**, so the Agent cannot invent new ones:
`proceed / skip / warn / propose-distill / propose-guide / require-validator / run-script:<relpath>`

**The single most important piece: the default `should-distill` post-hook**

```yaml
post:
  - name: should-distill
    when: "distill-candidates is non-empty"
    action: propose-distill
```

This hook **auto-applies to every skill, cannot be removed, cannot be weakened**. In plain English:

> Before any task ends, the Agent **must** explicitly evaluate "do I need to distill?" Silent skipping is forbidden.

I then mechanized its semantics in `validate.py`:
- `skip` is only legal in `pre` (no sneaking out right before the finish line).
- `propose-distill / propose-guide / require-validator` are illegal in `pre` (they are closing actions).
- `run-script:<path>` must exist, must be executable, and must live inside the skill directory (path-escape guard).

And each meta-skill now declares its own hooks:
- `distill.pre.have-candidates`: if the candidate list is empty, `skip` (so we never distill nothing).
- `distill.post.propose-guide` + `distill.post.validate-skills`: after writing skills, prompt `guide` to register them, and force the validator to run.
- `guide.post.validate-after-guide`: any `AGENT.md` edit must pass the validator.

**The breakthrough of this version**: the loop no longer depends on "the Agent remembering to complete it" — **the contract enforces completion**.

---

## 6. What a single task actually looks like inside this system

Let's walk a real flow: "help me review a Go PR". This is the narrative behind the pipeline diagram in the README.

1. **Execute starts**
   - Reads only §2 of `AGENT.md`; matches keywords `review / Go / PR` to `skills/review-go-pr/` (assume it already exists).
   - Lazy-loads its `SKILL.md`; expands `references/` only if needed.
2. **Run `pre` hooks**
   - `needs-go-toolchain` detects this is indeed a Go project → `proceed`.
3. **Run `How`**
   - Walk the SOP step by step. Along the way, spot a pitfall the skill didn't mention: "Go 1.22's `range over int` is being abused in this PR."
   - Push it into `distill-candidates`.
4. **Run `post` hooks**
   - Default `should-distill` fires → list is non-empty → propose `distill`.
   - User agrees.
5. **Distill**
   - Classify: the existing skill is incomplete → **Update** `review-go-pr/SKILL.md`, add a new Pitfall "range over int abuse", bump version `0.3.0 → 0.4.0`.
   - `post.validate-skills` forces `python3 scripts/validate.py` → passes.
   - `post.propose-guide` suggests invoking `guide`.
6. **Guide**
   - Scans front-matter; only the version changed, no registry row needs editing — just append one line to `AGENT.md` §7 changelog.
   - `post.validate-after-guide` runs the validator again → passes.
7. **Next time**
   - Anyone else throwing a Go PR in will hit the freshly-added pitfall. The loop is back to the start.

---

## 7. Patterns I deliberately avoided (anti-patterns)

All of these are explicitly banned in `AGENT.md` §6. I list them here so they don't silently creep back in:

- ❌ **Stuffing domain knowledge into `AGENT.md`** → sink it into a skill, or the Schema will bloat into an unmanageable index.
- ❌ **Bypassing the routing table and grepping `skills/`** → that's asking the Agent to guess, and it kills lazy-loading.
- ❌ **Skills importing each other's internals** → declare explicitly via `dependencies`.
- ❌ **A single `SKILL.md` over 500 lines** → spill into `references/` so the main file stays readable in one pass.
- ❌ **Duplicated knowledge across skills** → Merge, or extract a shared skill.
- ❌ **Using `pre.skip` as a substitute for "narrower triggers"** → fix the triggers instead; don't patch with hooks.
- ❌ **Silencing the default `should-distill` just because it's "nagging"** → that's exactly the lifeline of the loop.

---

## 8. Where this can evolve next (my roadmap)

I intentionally parked the project at v0.3.0, because going further requires **usage data**, not more design. I left room for a few future moves:

1. **Real domain-skill distillation**: today `skills/` contains only three meta-skills + the template; there are no real domain skills (`review-go-pr`, `debug-cuda-oom`, etc.). That needs the system to actually run for a while and let `distill` produce something real.
2. **A/B evaluation of `triggers`**: current triggers are just naive keyword + intent-string matching. The next step is to replay historical queries and use real hit-rates to prune dead triggers (the `guide` SOP already reserves this slot).
3. **Cross-repo skill sharing**: today a skill set belongs to a single repo. Could we stand up a skill registry so multiple projects share them? That requires `dependencies` to support cross-repo addressing — a big topic on its own.
4. **A script ecosystem around hooks**: `run-script:<relpath>` already supports local scripts, but there's no shared standard library yet. I could build a `hooks/` commons (e.g., "a `go-vet` post-hook shared by all Go skills").

---

## 9. Summary: what I'm actually shipping

In one sentence:

> I've built a minimal, runnable, self-evolving LLM Skill system: **a three-layer mental model (Raw / Wiki / Schema) + three meta-skills with mutually exclusive write rights (Execute / Distill / Guide) + a set of mechanical guards (contract + validator + Hook protocol)** — so the Agent can "read as little as possible" while "learning as much as possible".

The value isn't "yet another skill format". It's:

- **Grounding the LLM-Wiki intuition in a verifiable contract.**
- **Minimizing the parts that depend on "the Agent behaving well"** — everything else is mechanically guaranteed by front-matter, validator, and the Hook protocol.
- **Letting any Agent runtime (Codex / Claude Code / HERMES / custom) plug in via a thin shell file**, without being locked to any implementation.

---

# LLM-SKILL

最小可运行实现：https://github.com/hanyuancheung/llm-skill

> 这是我基于 Karpathy 的 [LLM-Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) 思想，一步步把想法落地成 `llm-skill` 项目的全过程记录。我会讲清楚：我从哪里出发、为什么要这样分层、每一层解决什么。

---

## 一、起点：我读 LLM-Wiki 读到了什么

Karpathy 在 LLM-Wiki 里抛出一个直觉——

> **人类不是靠背"所有对话"来变聪明的，而是把对话沉淀成词条，下一次遇到类似问题先查词条。**

把它翻译到 LLM Agent 的语境，我读到的关键信号是三个：

1. **上下文不是免费的。** 每次塞进 prompt 的内容都在烧 token、烧注意力，应该只塞"这次任务真正要用的那一小块"。
2. **经验需要一个"中间层"。** 原始对话是 raw，模型权重是 frozen，中间缺一个**可增量编辑的、结构化的经验层**——也就是 Wiki。
3. **Wiki 不是静态文档，是活体。** 有人写（沉淀）、有人读（执行）、有人整理（路由与健康度），三者必须分工。

所以我给自己定了一个设计命题：

> 做一个最小、可运行、可自我演进的 **Skill 系统**，让 Agent 的每一次任务都能：**读极少的信息 → 做对事情 → 把新学到的东西沉回 Wiki**。

---

## 二、我的三层心智模型：Raw / Wiki / Schema

在动手前我先强行把整个系统拆成三层，并规定**每一层只谈一件事**。这是我整个项目最底层的不变量。

| 层 | 对应物 | 谁写它 | 谁读它 |
|---|---|---|---|
| **Raw 层** | 会话、工具输出、报错、踩坑现场 | 用户 + Agent 临时产出 | 仅 `distill` 用来提炼 |
| **Wiki 层** | `skills/<name>/SKILL.md` | 只有 `distill` 能写 | `execute` 按需懒加载 |
| **Schema 层** | `AGENT.md`（路由 + 契约） | 只有 `guide` 能写 | `execute` 每次任务开头必读 |

**关键决定**：我把"领域知识"和"路由规则"彻底隔离。`AGENT.md` 里**一行领域知识都不允许出现**，它只回答"什么场景用什么 skill、它们怎么协作"。这样 Schema 才能做到稳定、短、可信。

这个三层模型在项目里直接体现为：

```
llm-skill/
├── AGENT.md            ← Schema（唯一真相源）
├── skills/
│   ├── execute/        ← 元技能：跑任务
│   ├── distill/        ← 元技能：写 Wiki
│   ├── guide/          ← 元技能：维护 Schema
│   └── _template/      ← 领域 skill 的脚手架
└── scripts/validate.py ← 契约守卫
```

---

## 三、闭环设计：Execute → Distill → Guide

如果只有分层，系统是静态的。我要的是**演进**，所以我在三层之上套了一个闭环：

```
          ┌────────────────────────────────────────────┐
          ▼                                            │
[Execute] ──traces──► [Distill] ──skill CRUD──► [Guide]
  跑任务                提炼沉淀                路由编排
  读 Schema                                    写 Schema
     ▲                                            │
     │                                            │
     └───────── 下一次任务被新规则路由 ◄───────────┘
```

我给三个元技能**互斥的写权限**，这是整套东西能不坏的根基：

| 元技能 | 读 | 写 | 绝对不能做 |
|---|---|---|---|
| `execute` | `AGENT.md` + 最多 3 个 `SKILL.md` | **什么都不写**（对 skill 只读） | 不得直接 `ls skills/`；不得改任何 skill |
| `distill` | Raw 层痕迹 + 现有 skill | 只写 `skills/<name>/SKILL.md` | 不得改 `AGENT.md` |
| `guide` | 所有 skill 的 front-matter | 只写 `AGENT.md` 的路由表和 changelog | 不得往 `AGENT.md` 里塞领域知识 |

**为什么写权限要互斥？**
因为一个能一边执行一边改自己规则的 Agent，调试起来是地狱。互斥之后，任何一次系统行为的变化都能被归因到"是哪一个元技能在哪一次动了哪一个文件"。

---

## 四、为什么 skill 必须长成"合同 + 正文"

这是我在 v0.1.0 就锁死的 **SKILL 契约**（见 `AGENT.md` §3）：

- **front-matter（合同）**：`name / version / status / triggers / dependencies / owner / updated`，7 个字段一个都不能少。
- **正文（六段结构）**：What / When（正反各 ≥ 2 例） / How（编号 SOP） / Examples / Pitfalls / Changelog。

我特别在意两件事：

1. **两个生命体征：`version` + `status`**
   - `version` 让我能做语义化升级（补丁 / 增 SOP 步骤 / 契约变更）。
   - `status` 让我能做**生命周期状态机**：`experimental → active → deprecated → removed`。一条 skill 从诞生到被淘汰都能被追踪。

2. **`Pitfalls` 必须来自真实痕迹**
   这是我为自己立的一条铁律——从 raw 里长出来的 pitfall 才有价值，凭空编的 pitfall 是污染。`distill` SOP 里专门把"每条 Pitfall 是否可以陈述为『若 A 则 B』"作为质量门。

3. **懒加载硬约束：每次任务最多 3 个 SKILL.md**
   这直接对应开头那句"上下文不是免费的"。`execute` 的 SOP 第 1 条就是"**只读 `AGENT.md` §2，禁止批量读 `skills/`**"。

---

## 五、三次迭代，我把这个东西做扎实的过程

这个项目不是一蹴而就的。我分三次版本把漏洞逐个补上——这部分直接对应仓库的 `CHANGELOG.md`：

### v0.1.0 — 先把骨架立起来

此时我只交付了最小闭环：
- `AGENT.md`：路由表 + SKILL 契约 + 生命周期状态机 + 反模式。
- 三个元技能目录：`execute / distill / guide`。
- `_template` 脚手架。

**这一版能解决的问题**：理念跑得通——Agent 能读 Schema、懒加载 skill、做完事情后提醒沉淀。

**这一版的缺陷**：
- 只有英文，多语种用户不友好。
- 没有入口文件适配不同 Agent 运行时（Codex/Claude Code/HERMES）。
- 没有任何机械化的守卫——契约全靠"信任 Agent 会遵守"。

### v0.2.0 — 让它能被真正"安装"和"校验"

我补了四件事：

1. **双语镜像**：每个 skill 同时提供 `SKILL.md`（英文默认）+ `SKILL_zh.md`（中文镜像），**front-matter 的 `name/version/status` 必须一致**，正文可以翻译。
2. **多运行时入口薄壳**：`AGENTS.md`（Codex）、`CLAUDE.md`（Claude Code）、`HERMES.md`（HERMES）——它们都**只是壳**，最终回指 `AGENT.md`。这样同一套 Schema 可以挂到任何 Agent 运行时。
3. **`install.sh`**：一键自检目录结构 + 调用校验器。
4. **`scripts/validate.py`**：校验三件事——front-matter 格式、目录名与 `name` 一致、`AGENT.md` §2 的注册表与 `skills/` 真实目录双向一致。

**这一版的核心突破**：从"靠 Agent 自觉"升级为"有一个机械守卫能拒绝错误的提交"。

### v0.3.0 — Hook 协议：把"我完事之前还要不要做点什么"机械化

这是我个人最满意的一次迭代。

**问题背景**：
`execute` 跑完任务后，理论上应该判断"这次是否产生了沉淀候选"。但"应该"两个字不够——Agent 会偷懒、会漏掉、会自我合理化说"这次没啥好沉淀的"。

**我的方案**：引入 **Hook 协议**（`AGENT.md` §10），给 skill 的生命周期开三个锚点：

| 阶段 | 触发时机 | 典型用途 |
|---|---|---|
| `pre` | skill 路由命中之后、执行 `How` 之前 | 守卫条件；`skip` / `warn` / `proceed` |
| `post` | `execute` 宣告"完成"之前 | 沉淀判定、校验器、副作用检查 |
| `on_error` | 任意步骤抛错或用户中止 | 清理、回滚、日志提取 |

**我定义了一份白名单动作**，Agent 不能自编：
`proceed / skip / warn / propose-distill / propose-guide / require-validator / run-script:<relpath>`

**最关键的一条：默认 `should-distill` post-hook**

```yaml
post:
  - name: should-distill
    when: "distill-candidates is non-empty"
    action: propose-distill
```

这条 hook **对每个 skill 自动生效，不允许删除、不允许弱化**。翻译成人话就是：

> 每次任务结束前，Agent 都**必须**明确评估"要不要去沉淀"，不能默默跳过。

我还在 `validate.py` 里把这条语义机械化了：
- `skip` 只能出现在 `pre`（不能让别人在完事前偷偷溜走）。
- `propose-distill / propose-guide / require-validator` 不能出现在 `pre`（它们是收尾动作）。
- `run-script:<path>` 的脚本必须存在、必须可执行、必须在 skill 目录内（防止路径越界）。

配合三个元技能各自声明的 hook：
- `distill.pre.have-candidates`：没候选就 `skip`（避免无意义的沉淀）。
- `distill.post.propose-guide` + `distill.post.validate-skills`：写完 skill 要提醒 `guide` 注册，并强制跑校验器。
- `guide.post.validate-after-guide`：改完 `AGENT.md` 必须过校验。

**这一版的核心突破**：闭环不再依赖"Agent 记得走完"，而是**契约强制走完**。

---

## 六、一次任务在我这套系统里究竟怎么跑

以"帮我 review 一个 Go PR"为例，走一遍完整流程——这也是 README 里那张 pipeline 图想表达的东西：

1. **Execute 启动**
   - 只读 `AGENT.md` §2，根据关键词 `review / Go / PR` 匹配到 `skills/review-go-pr/`（假设已存在）。
   - 懒加载它的 `SKILL.md`，如需要再加载 `references/`。
2. **跑 `pre` hooks**
   - `needs-go-toolchain` 检测到确实是 Go 项目 → `proceed`。
3. **执行 `How`**
   - 按 SOP 一步步来。过程中发现一个 skill 没写的坑：「Go 1.22 的 `range over int` 在这个 PR 里被滥用」。
   - 把它塞进 `distill-candidates`。
4. **跑 `post` hooks**
   - 默认 `should-distill` 触发 → 候选非空 → 提议走 `distill`。
   - 用户同意。
5. **Distill**
   - 分类：这是"现有 skill 记录不全" → **Update** `review-go-pr/SKILL.md`，在 Pitfalls 里加一条「range over int 滥用」，版本 `0.3.0 → 0.4.0`。
   - `post.validate-skills` 强制跑 `python3 scripts/validate.py` → 通过。
   - `post.propose-guide` 建议走 `guide`。
6. **Guide**
   - 扫 front-matter，发现只是版本号变了，注册表无需改行，只在 `AGENT.md` §7 追加一行 changelog。
   - `post.validate-after-guide` 再跑一次校验 → 通过。
7. **下一次**
   - 再有人扔 Go PR 过来，新加的 pitfall 已经躺在 skill 里等着被命中。闭环回到起点。

---

## 七、我刻意避开的那些"看起来很美"的做法（反模式）

这些我都在 `AGENT.md` §6 明确禁止了，写在这里是为了让它们不会被无声地回潮：

- ❌ **把领域知识往 `AGENT.md` 里塞**——下沉到 skill，否则 Schema 会膨胀成失控的索引。
- ❌ **绕过路由表直接 `grep skills/`**——那等于让 Agent 瞎猜，也废掉了懒加载。
- ❌ **skill 互相 import 对方的内部章节**——要依赖就在 `dependencies` 字段里显式声明。
- ❌ **单个 `SKILL.md` > 500 行**——拆到 `references/`，保持主文件可一次读完。
- ❌ **同一知识在多个 skill 重复**——强制 Merge 或抽一个共享 skill。
- ❌ **用 `pre.skip` 当作"更窄的 triggers"的替代品**——该收窄 triggers 就收窄，别用 hook 打补丁。
- ❌ **把默认 `should-distill` 静默掉只因为"嫌它烦"**——这恰恰是闭环的生命线。

---

## 八、还可以继续演进的方向（我的路线展望）

我有意把当前版本停在 v0.3.0，因为再往前走需要的是"使用数据"而不是"设计"。我预留了几个演进位：

1. **领域 skill 的真实沉淀**：目前 `skills/` 里只有三个元技能 + 模板，缺真实的领域 skill（例如 `review-go-pr`、`debug-cuda-oom`）。这需要让系统跑一段时间、让 `distill` 真的产出东西。
2. **`triggers` 的 A/B 评估**：目前 triggers 是关键词 + 意图字符串的朴素匹配。下一步我想加"历史 query 回放"，用真实命中率来淘汰空 trigger（`guide` SOP 里已经埋了这个位子）。
3. **跨仓库 skill 共享**：现在一套 skill 属于一个仓库。能不能做一个 skill 注册中心，让多个项目复用？这需要 `dependencies` 支持跨仓库寻址，是个大题目。
4. **Hook 的脚本生态**：目前 `run-script:<relpath>` 支持本地脚本，但标准库还是空的。可以做一个 `hooks/` 的公共库（比如"所有 Go skill 共享的 `go-vet` post-hook"）。

---

## 九、总结：我交付的是什么

一句话版本：

> 我做了一个最小、可运行、可自我演进的 LLM Skill 系统：**三层心智模型（Raw / Wiki / Schema）+ 三个互斥写权限的元技能（Execute / Distill / Guide）+ 一套机械守卫（契约 + 校验器 + Hook 协议）**，让 Agent 在"尽可能少读"的前提下"尽可能多学"。

它的价值不在"又发明了一个 skill 格式"，而在——

- **把 LLM-Wiki 的直觉落到了一套可复核的契约上**；
- **把"Agent 应该自觉"的部分降到了最低**，剩下的都靠 front-matter、validator、hook 协议机械保障；
- **让任何 Agent 运行时（Codex / Claude Code / HERMES / 自建）都能通过一个薄壳文件挂进来**，不绑死实现。