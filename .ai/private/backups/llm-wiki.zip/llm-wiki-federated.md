# federated-llm-wiki - Work In Progress

_a federated, pluggable LLM memory system_

A single [llm-wiki](https://gist.github.com/karpathy/b1e8ee0344ab92d92e7e2c4dc2c8a9e3) is good. But you will eventually want more than one. And then you'll want them to talk to each other. That's what this is.

federated-llm-wiki should let you deploy vaults in minutes, connect them in a clean DAG, plug in agents and UI components, and scale from a single personal wiki to a network of federated knowledge bases — covering completely unrelated topics — under one roof.

Not centralized — So, no global authority. Not decentralized — So, no trustless chaos. Federated: each vault governs its own knowledge; connections are explicit, directional, and acyclic.

---

## The vault

Each vault is a self-contained unit of **SwarmVault**:

```
swarmvault/
├── swarmvault.schema.md   # ontology, entity/category definitions, source vaults
├── raw/                   # immutable source files + external snapshots
├── wiki/                  # LLM-maintained markdown, disposable, generated from raw
├── state/                 # graph.json · SQLite (FTS + vector embeddings)
└── inbox/                 # approval-pending candidates (wiki-output → raw corridor)
```

The key insight from llm-wiki still holds: **wiki is disposable**. `raw/` is the source of truth. The LLM writes to `wiki/` during ingest. You promote things to `raw/` only when you're sure they belong there permanently.

Conflicts don't need immediate resolution. Let them sit in `inbox/`. If something keeps recurring, it probably belongs in the schema. Otherwise, dispose.

Entity and category counts are kept intentionally small. A sparse schema keeps the wiki evolvable and prevents premature canonicalization.

Ships with starter schemas to bootstrap your own ontology.

---

## Federation

This is where federated-llm-wiki diverges from a plain llm-wiki.

You connect vaults. Vault B can know about Vault A.

Each vault already exposes a `/query` endpoint for its frontend. Federation adds one more: `/summary` — a generated snapshot of what the vault knows, regenerable on demand.

To connect vault A to aggregator vault B: register A's summary URL as a source in B (`swarmvault source add https://vault-a.internal/summary`). The summary is pulled into `raw/`, ingested through the normal pipeline, and wiki pages, graph, and index are updated accordingly. B's schema (`swarmvault.schema.md`) holds a lightweight reference in its `sources:` section: vault name, endpoint, and topic areas. The full summary lives in `raw/` as any other ingested source.

Federated queries are handled by the runtime layer, not the LLM. When a query arrives at B:

1. Runtime checks B's schema `sources:` for connected vaults.
2. Decides which vaults are relevant (rule-based or quick LLM classification).
3. Fans out `/query` requests to relevant vaults in parallel.
4. Merges remote results with local wiki/raw context.
5. Builds the final prompt and sends it to the LLM.

The LLM never calls external vaults directly — the runtime owns the fan-out. This keeps routing deterministic, parallelizable, and independent of SwarmVault internals.

Queries are of two types: a normal `query` gathered from wiki content, and a `grounded-query` that retrieves the source as-is for various purposes.

The dependency graph must be a **DAG** (directed acyclic graph) — circular dependencies are not allowed.

```
[Vault A]  [Vault B]  [Vault C]
     \          |         /
      \         |        /
       [Aggregator Vault 1]  [Vault D]  [Aggregator Vault 2]
                    \           |            /
                     \          |           /
                      \         |          /
                       [Aggregator Vault 3]
```

The aggregator is structurally identical to any other vault — just a different schema and different raw content that describes the network. Any vault can be an aggregator. There is no special central node.

Each vault maintains its own ontology. When it pulls from sources, it decides what matters _to it_ and how to frame it. Two aggregators can point to the same source vaults and produce completely different knowledge representations.

---

## Deploy

One container = one vault. To spin up a new node, you need a URL and a few env vars:

```
BACKEND_URL=...
API_KEY=...
MODEL=...
EMBEDDING_MODEL=...
VAULT_SOURCES=vault-a.internal,vault-b.internal
```

Frontend is a separate container, also just env vars. Attach it to any backend. Run a vault headless (terminal + MCP only) or with a full UI. Connect one frontend to multiple backends or one backend to multiple frontends.

External content — GitHub repos, Azure DevOps, arbitrary URLs, Excel files — is pulled in as snapshots. Snapshot triggers are configurable per container: **webhook**, **scheduled (cron)**, or **manual** (terminal or UI).

**Whenever possible** sources are always registered as URLs, not mounted volumes. SwarmVault handles cloning and snapshot management internally — no need to manage a local copy yourself. For repos, the webhook listens to the release branch so the vault stays in sync with stable code, not every work-in-progress push.

---

## Query

Wiki is always the first stop. Queries hit the wiki via FTS + embeddings + graph traversal. If the answer is there, return it. No LLM generation needed. To increase query performance the LLM can cooperate with scripts, embeddings, reranker, etc. Configurable.

```
query
  → index.md (frontmatter-based graph entry points, configurable)
  → wiki → graph search
  → response
```

Wiki is a lossy compression of raw. It captures concepts, relationships, and summaries — not every formula, constant, or line of code. That's by design. A well-maintained wiki covers most queries, but some require source-level detail.

### Grounded-Query

When wiki output is insufficient, the agent navigates to raw on its own. The wiki already narrows the search: file paths, entity names, graph pointers. The agent follows those leads — reads the raw file, extracts the relevant block, returns it.

This is not a separate query mode or an automatic fallback. It's the agent's judgment call, guided by wiki context. No special mechanism needed: the agent has raw access (via MCP or direct file read) and the wiki tells it where to look.

```
"show me the retry implementation"
  → wiki: "auth module, src/auth.py, exponential backoff, max 3"
  → agent decides: wiki answer is insufficient, user wants code
  → signals "extending search to sources" (thinking/streaming feedback)
  → follows wiki pointers → reads raw/repo-x/src/auth.py
  → returns the relevant code block
```

Keeping the wiki well-maintained means the agent rarely needs to go to raw — that's the core insight from llm-wiki. When it does, wiki context makes the lookup fast and targeted rather than a blind search through the entire source corpus.

---

## Folder structure

```
your-vault/
├── swarmvault/   # vault core: ingest · query · lint · MCP server · CLI
├── agents/       # agent definitions, meeting room formats
├── skills/       # skill definitions used by agents
└── runtime/      # fan-out reasoning layer, promptBuilder, request orchestration
```

The runtime wraps swarmvault. Instead of querying the vault and handing the result straight to the LLM, it fetches raw context, builds a prompt, fans out to parallel subagents, and merges:

```
request
  → raw context fetch  (swarmvault CLI / MCP)
  → promptBuilder
  → parallel subagents  [A1] [A2] [A3]
  → merge + optimize
  → response
```

---

## Agent Meeting Rooms

Agents live in `agents/`. Two patterns:

**Graph interpreter** — multiple agents read the same knowledge graph from different angles, hold a structured meeting, synthesize a result.

**Content review** — generate output from the graph, then run agents over that output with different concerns (accuracy, completeness, tone, consistency) in parallel to optimize before returning.

Meeting format, participant definitions, and skills are all configurable. Session context is `--no-save` by default.

Inspired by **Garry Tan's `GBrain` and `GStack`**

No specific structure is enforced. An example: spawn a customer-service agent with a set of skills. Or bring in an engineer, a release-manager, and a customer-service agent together to discuss whether something is feasible in the next version of your product.

---

## UI plugins

### Container mode

Frontend is React + Module Federation. UI plugins are published to a package registry as separate packages and lazy-loaded at runtime:

```
@org/chat           # base chat component
@org/showcase       # lite mode container + config UI
@org/plugin-pdf     # PDF viewer
@org/plugin-graph   # knowledge graph visualizer
@org/plugin-map     # map
@org/plugin-vault   # vault related operations like approval queue
@org/plugin-*       # swarmvault outputs or any custom-defined output type
```

Adding or removing a plugin is a deployment config change, not a code change. The showcase container reads active plugins from env and loads them at startup.

### UI Component mode

Components are also available independently — use them inside your own project with your own UI. The chat component ships with sensible defaults but is fully customizable. Plugin components activate when interacting with chat messages. Vault concepts like inbox management, candidate approval, and review flows are available as plugin components — import and render on message receive.

---

## Why not just a plain llm-wiki?

A single llm-wiki is fine when you have one knowledge domain and one user.

But:

- You want separate vaults for separate projects that occasionally need to query each other
- You want one vault to be aware of several others without polluting its own ontology
- You want completely unrelated topics to coexist in one federated network without cross-contamination
- You want different teams or users to maintain their own perspective on shared source vaults
- You want to swap UI components, agents, and reasoning styles without rebuilding the core

federated-llm-wiki handles all of this. Each vault is still just an llm-wiki at its core — raw, wiki, ingest, query, lint. The federation and plugin layers are additive, not invasive.

The vault doesn't know it's in a bigger network than itself. The network is just configuration.

TODO:

1. Step 5 in Federation section: what if context limit is exceeded by the documents retrieved (solution notes: 1. subagents summarise accordingly then merge then request?)
2. Routing algorithms for huge raw files when **explicitly** requested.
3. Vault and backend separation — is it nonsense? They're almost hugging each other.
4. Some concepts not implemented yet — meeting logging, gbrain-like access control, scripts to help llm, dream-lint
5. Need a plugin to upload files to the container or UI. Then, how does ingest work? from the UI? Does lint run from UI too?
6. Partial-access memory — authorized access to vault contents.
7. A map to route into raw — is it needed, is it right, is it even appropriate?
8. Question-based "schema" generation via pre-built skills and pre-built templates for quick usage.
9. An optional strict ontology checker layer with owl, rdf, ttl?
10. Agent config: model selections like chat, completion, vision, embedding, tts, stt...
