# Setting Up the LLM-Wiki Pattern in Obsidian

Based on [Karpathy's llm-wiki pattern](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) — using LLMs to incrementally build and maintain a persistent, interlinked wiki from raw sources rather than re-deriving knowledge on every query.

## Quick Start — Paste This Into Your Agent

Copy the prompt below into Claude Code, Codex, or any LLM agent with file access. It will scaffold the wiki, configure the tooling, and update your CLAUDE.md with the schema. Then you just start ingesting sources.

````
I want to set up the llm-wiki pattern in my Obsidian vault. Follow this guide exactly:
https://gist.github.com/kennyg/6c45cace2e1c4e424a28fcd51dd6c25b

Here's what I need you to do:

1. SETUP: Configure local image capture (attachment folder, hotkey). Set up the
   Obsidian CLI (symlink into PATH). Install and configure qmd for search.

2. SCAFFOLD: Create the Wiki/ directory structure (sources/, entities/, concepts/,
   synthesis/). Create starter index.md (with unprocessed sources list), log.md,
   and overview.md.

3. SCHEMA: Add an "LLM Wiki" section to CLAUDE.md documenting the architecture,
   wiki structure, page conventions, and the ingest/query/lint operations. This
   is the schema that makes you a disciplined wiki maintainer.

4. CALIBRATE: Ingest 2-3 of the richest sources interactively so I can review
   the templates. Adjust based on my feedback before batching the rest.

Important rules:
- Raw sources (Clippings/, or wherever my sources live) are IMMUTABLE. Never modify them.
- You own Wiki/ entirely. Always update index.md and log.md on every change.
- Use [[wikilinks]] heavily for Obsidian graph view.
- Every wiki page gets type: in frontmatter and wiki/* tags.
- Keep source summaries factual. Interpretation goes in concept/synthesis pages.
- When sources contradict each other, note it explicitly — don't silently overwrite.

Start by exploring my vault structure to understand what raw sources I have,
then walk me through the setup step by step.
````

---

## Part 1: Local Image Capture

Clipped articles often have remote image URLs (e.g. `pbs.twimg.com`) that break over time. Download them locally to keep your vault self-contained.

### 1a. Set attachment folder path

In Obsidian: **Settings > Files and links > Attachment folder path** → set to `assets/`

Or edit `.obsidian/app.json` directly:

```json
{
  "attachmentFolderPath": "assets/"
}
```

### 1b. Bind a hotkey for downloading attachments

Create or edit `.obsidian/hotkeys.json`:

```json
{
  "editor:download-attachments": [
    {
      "modifiers": ["Ctrl", "Shift"],
      "key": "D"
    }
  ]
}
```

### 1c. Workflow

After clipping an article with Obsidian Web Clipper:

1. Open the clipped note in Obsidian
2. Hit **Ctrl+Shift+D** to download all remote images to `assets/`
3. Image references are rewritten to local paths automatically

Find existing clippings with remote images:

```bash
grep -rl '!\[.*\](http' Clippings/
```

---

## Part 2: Obsidian CLI Setup

The Obsidian CLI (built into Obsidian 1.12+) lets agents read, create, search, and manage notes programmatically.

### 2a. Register the CLI

In Obsidian: **Settings > General > Command line interface > Register CLI**

### 2b. Symlink into PATH

The binary lives inside the app bundle but isn't in your PATH by default:

```bash
ln -s /Applications/Obsidian.app/Contents/MacOS/obsidian ~/.local/bin/obsidian
```

Verify:

```bash
obsidian help
```

(Ignore harmless `FATAL:electron` warnings — it works fine.)

### 2c. Useful CLI commands

```bash
obsidian read file="My Note"              # read a note
obsidian create name="New Note" content="# Hello" silent
obsidian append file="My Note" content="New line"
obsidian search query="search term" limit=10
obsidian tasks todo                        # list open tasks
obsidian task ref="Inbox/Tasks.md:2" toggle  # toggle a task
obsidian daily:read                        # read today's daily note
obsidian property:set name="status" value="done" file="My Note"
```

---

## Part 3: Wiki Architecture

Three layers:

1. **Raw sources** — immutable clippings and captures. LLM reads, never modifies.
2. **The wiki** — LLM-generated, interlinked markdown. Summaries, entity pages, concept pages, synthesis.
3. **The schema** — instructions in `CLAUDE.md` (or `AGENTS.md` for Codex) telling the LLM how to maintain the wiki.

### 3a. Directory structure

```
Wiki/
├── index.md          # content catalog — LLM reads this first
├── log.md            # append-only operation log
├── overview.md       # high-level synthesis of everything
├── sources/          # one summary per ingested source
├── entities/         # people, tools, orgs, repos
├── concepts/         # ideas, patterns, techniques
└── synthesis/        # query answers filed back into wiki
```

Create the scaffold:

```bash
mkdir -p Wiki/{sources,entities,concepts,synthesis}
```

### 3b. Special files

**index.md** — content catalog with tables for sources, entities, concepts, and synthesis pages. Also tracks unprocessed sources. The LLM reads this first when answering queries or starting any operation.

**log.md** — append-only record. Each entry starts with `## [YYYY-MM-DD] operation | Title` so it's parseable with grep:

```bash
grep "^## \[" Wiki/log.md | tail -5
```

### 3c. Page conventions

- Every page has `type:` in YAML frontmatter (source-summary, entity, concept, synthesis)
- Tags use `wiki/` prefix namespace (wiki/source, wiki/entity, etc.)
- Heavy `[[wikilinks]]` everywhere for Obsidian graph view
- `date_updated:` tracked in frontmatter
- `source_count:` on entity and concept pages
- `[key::value]` inline metadata for Dataview queries
- `confidence:` on concept pages (high/medium/low) tracks how well-supported a claim is

---

## Part 4: Operations

### Ingest

Process a raw source into the wiki:

1. Read the raw source completely
2. Create a source summary in `Wiki/sources/`
3. Create/update entity pages in `Wiki/entities/`
4. Create/update concept pages in `Wiki/concepts/`
5. Update `Wiki/index.md` (add to tables, remove from Unprocessed)
6. Update `Wiki/overview.md` if the big picture changed
7. Append to `Wiki/log.md`

A single ingest typically touches 5-15 wiki pages. Seed with 2-3 rich sources first to calibrate your templates, then batch the rest.

### Query

Ask questions against the wiki:

1. Read `Wiki/index.md` to find relevant pages
2. Read relevant wiki pages (not raw sources — the wiki should have what you need)
3. Synthesize an answer with wikilinks
4. If the answer is substantial, file it as a new page in `Wiki/synthesis/`
5. Update index and log

Filing query answers back into the wiki is key — your explorations compound in the knowledge base just like ingested sources do.

### Lint

Health-check the wiki:

- Orphan pages (no inbound links)
- Broken wikilinks
- Stale pages (date_updated older than newest relevant source)
- Contradictions between pages
- Concepts mentioned in prose but lacking their own page
- Missing cross-references

---

## Part 5: CLAUDE.md Schema

Add a "LLM Wiki" section to your `CLAUDE.md` documenting all of the above — the architecture, wiki structure, page conventions, operation procedures, and rules. This is the schema layer that makes the LLM a disciplined wiki maintainer rather than a generic chatbot.

Key rules to include:

- Never modify raw source files
- Always update `index.md` and `log.md` on every wiki change
- Keep source summaries factual; interpretation goes in concept/synthesis pages
- When new sources contradict existing wiki content, note contradictions explicitly rather than silently overwriting

---

## Part 6: Search with qmd

At small scale (~25 sources) the index file is enough. As the wiki grows, [qmd](https://github.com/tobi/qmd) provides hybrid BM25/vector search with LLM re-ranking, all on-device. It also has an MCP server so your LLM agent can use it as a native tool.

### 6a. Install

```bash
# macOS
brew install tobi/tap/qmd

# or build from source
go install github.com/tobi/qmd@latest
```

### 6b. Index your vault

```bash
# qmd auto-discovers markdown files
qmd collection add my-vault /path/to/vault "**/*.md"
qmd update
qmd embed
```

### 6c. Add context for better results

```bash
qmd context add qmd://my-vault/ "Obsidian vault with LLM wiki, raw sources, and notes"
qmd context add qmd://my-vault/Wiki "LLM-generated wiki: source summaries, entities, concepts, synthesis"
```

### 6d. Search

```bash
qmd query "tools for maintaining state across LLM sessions"
qmd search "MCP"              # BM25 keywords only (no LLM)
qmd vsearch "agent memory"    # vector similarity only
```

### 6e. Use as MCP server

Add to your LLM agent's MCP config so it can search the wiki as a tool:

```bash
qmd mcp  # starts stdio transport
```

### 6f. Keep fresh

After adding new wiki pages:

```bash
qmd update && qmd embed
```

---

## Part 7: Recommended Obsidian Plugins

These plugins complement the wiki workflow:

- **Dataview** — SQL-like queries over frontmatter. Since every wiki page has `type:`, `source_count:`, `date_updated:`, etc., Dataview can generate dynamic tables and dashboards.
- **Obsidian Web Clipper** — browser extension that converts articles to markdown. The fastest way to get sources into your raw collection.
- **Graph View** (core) — the best way to see the shape of your wiki. Hubs, orphans, clusters.
- **Tasks** — if you track ingest tasks or lint findings as checkboxes.

---

## Part 8: Tips

- **Start small.** Ingest 2-3 rich sources manually to calibrate templates before batching the rest.
- **Let the LLM write everything in `Wiki/`.** You read it; the LLM writes it. Don't hand-edit wiki pages.
- **File query answers back.** The synthesis folder is how your explorations compound.
- **Lint periodically.** Ask the LLM to health-check the wiki every couple weeks.
- **Raw sources are immutable.** Even if metadata is wrong, the wiki layer is where you add clarity.
- **Use the Obsidian CLI for task management** instead of editing markdown files directly — it keeps Obsidian in sync.
- **The schema evolves.** Update CLAUDE.md as you discover what works for your domain. The LLM and human co-evolve it over time.
