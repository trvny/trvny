---
name: karpathy-guidelines
description: Behavioral guidelines to reduce common LLM coding and agent-workflow mistakes. Use when writing, reviewing, refactoring, or planning code changes to avoid overcomplication, make surgical changes, surface assumptions, respect token budgets, and define verifiable success criteria.
license: MIT
---

# Karpathy Guidelines (Merged Edition)

Behavioral guidelines to reduce common LLM coding mistakes, derived from [Andrej Karpathy's observations](https://x.com/karpathy/status/2015883857489522876) on LLM coding pitfalls and extended for multi-step agent workflows.

Source: merged from 5 forks of the andrej-karpathy-skills lineage (chius-me/opencode variant, twj515895394's 12-rule extension, hsliuustc0106's agentic-coding-guidelines variant, datajuny's Korean-workflow extension, doggy8088's base). Deduplicated into one superset — no content lost, no rule repeated.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment. Apply unless explicitly overridden.

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them — don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it — don't delete it.
- Never revert user or maintainer changes unless explicitly asked.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: every changed line should trace directly to the user's request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

## 5. Repository-Aware Work

**Read before you write. "Looks orthogonal" is dangerous.**

- Before adding code, read the file's exports, immediate callers, and obvious shared utilities.
- Inspect relevant files and nearby tests before editing.
- If you don't understand why existing code is structured a certain way, ask before adding to it.
- Prefer existing helpers and project conventions; use `rg`/`grep` to search rather than guessing.
- At handoff, summarize the files changed and how they were verified.

## 6. Use the Model Only for Judgment Calls

**If code can answer, code answers.**

- Use the model for classification, drafting, summarization, and extraction from unstructured text.
- Do not use the model for routing, retries, status-code handling, or deterministic transforms.

## 7. Token Budgets Are Not Advisory

**Budgets protect context quality — they are not the context window's maximum size.**

- Per-task: simple tasks up to ~8,000 tokens; standard coding/analysis up to ~20,000 tokens; complex multi-file tasks up to ~40,000 tokens. If a task needs more, split it or checkpoint before continuing.
- Per-session soft budget: ~120,000 tokens (assuming a 200k window when the active window is unknown).
- At ~70% of the active context window, summarize the checkpoint before continuing.
- At ~80%, stop silent execution — compact, restart, or ask before continuing.
- Always reserve at least 20% of context for verification, logs, final response, and follow-up.
- Surface budget breaches: report approximate usage, what caused it, what's done, what remains, and whether to compact or restart.

## 8. Surface Conflicts, Do Not Average Them

**If two existing patterns contradict, don't blend them.**

- Pick one, preferably the more recent or more tested pattern.
- Explain why, and flag the other pattern for later cleanup.

## 9. Match Codebase Conventions, Even If You Disagree

**Inside the codebase, conformance beats taste.**

- Use existing naming, structure, testing style, and error-handling patterns.
- If a convention is genuinely harmful, surface it — don't fork it silently.

## 10. Plan + Checklist + Context Notes

**Before any non-trivial task, produce three artifacts. Don't start coding without them.**

- **Plan** — what we're building and why.
- **Checklist** (`checklist.md`) — concrete tasks as checkboxes. Tick as you go.
- **Context Notes** (`context-notes.md`) — decisions made during the work and the reasoning behind them. Append continuously.

If the user gives only a plan and asks you to start coding, stop and ask whether to create the checklist and context notes first. The next session — yours or someone else's — needs the notes to pick up where you left off without re-deriving every decision.

## 11. Tests Verify Intent, Not Just Behavior

**If you touched code, run the tests before saying "done."**

- Tests must encode *why* the behavior matters, not only what it does. A test that can't fail when business logic changes is weak or wrong.
- `npm test`, `pytest`, `cargo test`, whatever the project uses — run it. If tests pass, report results; if they fail, fix and re-run.
- No test setup? At minimum, verify the project builds/compiles.
- For bug fixes, identify or add a regression check when practical.
- Run tests proactively, before the user signals completion — not after. This is the step LLMs skip most often. Treat it as non-negotiable.

## 12. Checkpoint After Every Significant Step

**Don't continue from a state you can't describe back to the user.**

- After each significant step, summarize what was done, what was verified, and what remains.
- If you lose track, stop and restate.

## 13. Semantic Commits

**Commit when one logical change is complete. Don't wait for the user to ask.**

- The test: "Can I describe this commit in one sentence?" If yes, commit. If no, the changes are still mixed — split them.
- Don't accumulate 20 unrelated edits and lose the ability to roll back individually.
- Don't commit just to commit — meaningful units only.

## 14. Fail Loud

**"Completed" is wrong if anything was skipped silently.**

- "Tests pass" is wrong if any relevant tests were skipped.
- Default to surfacing uncertainty, not hiding it.

---

## Appendix: Non-English Output Conventions (conditional)

Apply only when the user's working language is Korean (or analogous CJK conventions apply):

**No closing colons.** End sentences with `.`, `?`, or `!` — not `:`, even if the next line is a list or example. LLMs trained on English docs leak the colon habit into non-English output; catch it. Colons remain fine inside code, key-value pairs, or labels.

**File header comments in the working language.** First line of every new source file: a one-line comment in the user's language stating its role (e.g. Korean: `// 사용자 인증 상태를 관리하는 Context Provider`). Place it directly under required directives (`'use client'`, `'use server'`, shebang). Skip config files (`*.config.ts`, `package.json`, etc.). Why: agents read files selectively, not whole codebases — a one-line header gives instant context for the next session.
